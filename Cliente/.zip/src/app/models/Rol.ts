export class Rol{
    id_rol: number;
    nombre_rol : string;
    name_rol: string;

    constructor() {
        this.id_rol = 0;
        this.nombre_rol = "";
        this.name_rol = "";
    }
}