export const environment = {
  production: false,
  API_URI: "http://localhost:3000/api",
  API_URI_CORREOS: "http://localhost:3001",
  API_URI_IMAGES: 'http://localhost:3002',
  };