export const environment = {
  production: true,
  API_URI: "http://localhost:3000/api"
};
