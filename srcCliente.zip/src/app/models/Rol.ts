export class Rol{
    id_rol: number;
    nombre_rol : string;

    constructor() {
        this.id_rol = 1,
        this.nombre_rol = "Administrador"
    }
}